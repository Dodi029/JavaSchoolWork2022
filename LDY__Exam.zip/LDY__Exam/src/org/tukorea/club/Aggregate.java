package org.tukorea.club;

public interface Aggregate {
	public Iterator createIterator();
}
