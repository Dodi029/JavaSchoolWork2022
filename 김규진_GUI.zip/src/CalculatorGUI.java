import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class CalculatorGUI extends JFrame {
	private JLabel ResultLabel, TempLabel;
	// private String equation = "";
	private boolean inputState, resultState = false;
	private String operation, numberInput = "";
	private double num1, num2, result;
	private JButton cButton = new JButton("C");
	static boolean isInt(double d) {
		return d == (int) d;
	}
	
	void setNum1(String op) {
		num1 = Double.parseDouble(ResultLabel.getText());
		operation = op;
		numberInput ="";
		if (isInt(num1))
			TempLabel.setText((int) num1 + op);
		else
			TempLabel.setText(num1 + op);
		inputState = false;
	}
	
	void printResult(String op) {
		switch(op) {
		case "+":
			result = num1 + num2;
			break;
		case "-":
			result = num1 - num2;
			break;
		case "x":
			result = num1 * num2;
			break;
		case "/":
			result = num1 / num2;
			if(num1 ==0 || num2 == 0) {
				ResultLabel.setText("0으로 나눌 수 없습니다");
				return;
			}
			break;
		case "%":
			result = num1 % num2;
			break;
		}
		if (isInt(result))
			ResultLabel.setText(String.valueOf((int) result));
		else
			ResultLabel.setText(String.valueOf(result));
		if (isInt(num2))
			TempLabel.setText(TempLabel.getText() + (int) num2 + "=");
		else
			TempLabel.setText(TempLabel.getText() + num2 + "=");
		inputState = false;
	}

	public CalculatorGUI() {
		setTitle("김규진 - 2019150003");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Container c = getContentPane();
		c.setLayout(null);
		ClockPanel clock = new ClockPanel();

		ResultLabel = new JLabel();
		ResultLabel.setText(Integer.toString(0));
		ResultLabel.setFont(new Font("Bauhaus", Font.BOLD, 40));
		ResultLabel.setHorizontalAlignment(JLabel.RIGHT);
		ResultLabel.setBounds(0, 120, 480, 100);
		ResultLabel.setOpaque(false);
		ResultLabel.setBackground(Color.gray);
		ResultLabel.setForeground(Color.LIGHT_GRAY);

		TempLabel = new JLabel();
		TempLabel.setFont(new Font("Gothic", Font.BOLD, 20));
		TempLabel.setHorizontalAlignment(JLabel.RIGHT);
		TempLabel.setBounds(0, 110, 480, 20);
		TempLabel.setForeground(Color.LIGHT_GRAY);

		JPanel calculate = new JPanel();
		calculate.setLayout(new GridLayout(5, 4, 5, 5));
		String button_names[] = {" ", "%", "/", "9", "8", "7", "x", "6", "5", "4", "-", "3", "2", "1", "+", " ",
				"0", ".", "=" };
		JButton b[] = new JButton[button_names.length];
		cButton.setFont(new Font("여기어때 잘난체 OTF 굵게", Font.BOLD, 30));
		cButton.addActionListener(new ShowListener());
		cButton.setOpaque(true);
		cButton.setBackground(Color.RED);
		cButton.setForeground(Color.WHITE);
		calculate.add(cButton);
		calculate.setBackground(Color.DARK_GRAY);
		
		for (int i = 0; i < b.length; i++) {
			b[i] = new JButton(button_names[i]);
			b[i].setFont(new Font("Bauhaus", Font.BOLD, 30));
			b[i].setOpaque(true);
			b[i].setForeground(Color.black);
			b[i].setBackground(Color.gray);
			if (i == 0 || i == 15) {
				b[i].setBackground(Color.gray);
				b[i].setEnabled(false);
			}
			if(i==0 || i==1 || i==2 || i == 6 || i == 10 || i ==14 || i==18)
				b[i].setBackground(Color.LIGHT_GRAY);
			b[i].addActionListener(new ShowListener());
			calculate.add(b[i]);
		}

		clock.setBounds(0, 0, 500, 100);
		calculate.setBounds(0, 220, 500, 300);
		c.add(clock);
		c.add(ResultLabel);
		c.add(TempLabel);
		c.add(calculate);
		setSize(500, 600);
		setVisible(true);
		c.setBackground(Color.DARK_GRAY);
	}

	private class ShowListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			JButton b = (JButton) e.getSource();
			String input = b.getActionCommand();

			switch (input) {
			case "C":
				ResultLabel.setText("0");
				inputState = false;
				TempLabel.setText("");
				numberInput ="";
				break;
			case "CE":
				if(resultState)
					TempLabel.setText("");
				ResultLabel.setText("0");
				inputState = false;
				numberInput ="";
				cButton.setText("C");
				break;
			case "+":
			case "-":
			case "x":
			case "/":
			case "%":
				setNum1(input);
				break;
			case "=":
				resultState = true;
				if(num2 != 0) {
					if(inputState)
					printResult(operation);
				}
				else {
					ResultLabel.setText("0");
					TempLabel.setText(ResultLabel.getText()+input);
				}
				break;
			default:
				if (inputState) {
					ResultLabel.setText(ResultLabel.getText() + input);
					numberInput += input;
					num2 = Double.parseDouble(numberInput);
				} else {
					resultState = false;
					inputState = true;
					numberInput += input;
					ResultLabel.setText(input);
					num2 = Double.parseDouble(numberInput);
					cButton.setText("CE");
				}
				break;
			}
		}
	}

	public static void main(String[] args) {
		new CalculatorGUI();
	}
}
