import java.awt.*;
import java.awt.event.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import javax.swing.*;

public class Clock extends JPanel {
	public Clock() {
		setLayout(null);
		JLabel ClockLabel = new JLabel();
		
		ClockLabel.setFont(new Font("monospaced", Font.BOLD, 60));
		ClockLabel.setForeground(Color.DARK_GRAY);
		ClockLabel.setHorizontalAlignment(JLabel.CENTER);
		ClockLabel.setBounds(0, 0, 500, 100);
		
		ClockThread thread = new ClockThread(ClockLabel);
		thread.start();
		
		setBackground(Color.BLACK);
		add(ClockLabel);
	}
	
	class ClockThread extends Thread {
		private JLabel ClockLabel;
		
		public ClockThread(JLabel ClockLabel) {
			this.ClockLabel = ClockLabel;
		}
		
		public void run() {
			LocalTime time = LocalTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
			
			while(true) {
				ClockLabel.setText(time.format(formatter));
				try {
					time = LocalTime.now();
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					return;
				}
			}
		}
	}
}
